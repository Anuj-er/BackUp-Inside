# Sample Python Script
def hello():
    print('Hello from AutoStash!')

if __name__ == '__main__':
    hello()
